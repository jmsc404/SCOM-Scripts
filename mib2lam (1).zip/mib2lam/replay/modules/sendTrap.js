var snmp=require('/usr/lib/node_modules/net-snmp');

// Generic validate OID

var validateOID=function(oid) {

	// We should always start with a 1.3 followed by any number of \.\d+ combinations;
	return /1.3(\.\d+){1,}/.test(oid) ? true : false;
};

// Generic validate varbind type. 

var validateVarbindType=function(type) {

	var valid={
		"Boolean" :  true,
		"Integer" :  true,
		"OctetString" :  true,
		"Null" :  true,
		"OID" :  true,
		"IpAddress" :  true,
		"Counter" :  true,
		"Gauge" :  true,
		"TimeTicks" :  true,
		"Opaque" :  true,
		"Integer32" :  true,
		"Counter32" :  true,
		"Gauge32" :  true,
		"Unsigned32" :  true
	};
	return valid[type] ? true : false;
};

		
// Snmp Session initialiser and functions. 

var SnmpSession=function() {
	this.destination="localhost";
	this.commString="public";
	this.session=false;
	this.options= { port : 161, 
			retries : 1, 
			timeout : 5000, 
			transport : "udp4" , 
			trapPort : 162, 
			version : snmp.Version2c 
	};
	this.createSession=function() {
		this.session=snmp.createSession(this.destination,this.commString,this.options);
		this.session.on("error", function(error) {
			console.log("Error: SNMP Session Error - " + error);
		});
		this.session.on("close", function() {
			console.log("SNMP Session terminated");
		});
		return { session: this.session, options: this.options , destination: this.destination, community: this.commString };
	};

	this.setTrapHost=function(dest) {
		this.destination= dest ? dest : "localhost";
	};

	this.setTrapPort=function(port) {
		this.options.trapPort= port || 162;
	}

	this.setCommunity=function(cstring) {
		this.commString= cstring ? cstring : "public";
	};

	this.sessionClose=function() {
		if ( this.session ) {
			this.session.close();
		}
	};
		
};
// SNMP Trap sender and functions. 

var SnmpTrap=function(session) {
	
	this.varbinds=[];
	this.trapOid="1.3.6.1.4.1.31949.1";
	this.snmpSession=session;
	
	this.addVarbind=function(oid,type,value) {

		value = value.replace(/(^\"|\"$)/g,"");
	
		if ( !validateVarbindType(type) )  {
			console.log("Error : " + type + " is not s supported varbind type");
			return;
		}
		if ( !validateOID(oid) )  {
			console.log("Error : " + oid + " is not s valid OID - expected 1.3.6.etc.");
			return;
		}
		this.varbinds.push( { oid : oid, type : snmp.ObjectType[type] , value : value } );
	};

	this.setTrapOID=function(oid) {
		if ( validateOID(oid) ) {
			this.trapOid=oid;
		}
		else {
			console.log(oid);
			console.log("Error: Trap OID must of the form 1.3.x etc.");
		}
	};

	this.sendTrap=function() {
		this.snmpSession.session.trap (this.trapOid, this.varbinds, function (error) {
    			if (error) {
				console.error (error);
				return false;
			}
		});
	};
	this.printVarbinds=function(){
		console.log(this.varbinds);
	};

};

// Exports

exports.SnmpTrap = SnmpTrap;
exports.SnmpSession = SnmpSession;
exports.validateVarbindtype = validateVarbindType;
exports.validateOID = validateOID;
