
var stripOIDValue=function(oid) {
        // We should always start with a 1.3 followed by any number of \.\d+ combinations;
	var isOID=/^.(1.3(?:\.\d+){1,}$)/.exec(oid);
	if ( isOID && isOID.length === 2) {
		return isOID[1];
	}
	else {	
		return oid;
	}
};


var processLine=function(trapData,line) {
		
	if ( line === "EACHLINE_COMPLETE" ) {

		// Reached the end - try and send what we have.	
		// if it's populated. 

		if ( trapData.trapOID && trapData.new === false ) {
			trapData.sendTrap=true;
			return trapData; 
		}
	}

	if ( /^\s+$/.test(line) ) {
		return trapData;
	}
	// We'll add the source IP address as the snmpTrapAddress on replay - the LAMbot can use this as the soure if needed. 
	// This is all contained on a single line - so we'll grab the OID value pairs and process. 

	var trapRegEx=/^\s+((?:\d{1,3}\.){3}\d{1,3})\.\S+\s+>\s+((?:[a-z0-9]+(?:\.|:|-|_)*){1,}):\s?(?:\[.*?\])?\s+{\s+SNMPv2c\s+(?:C=.*?)?\s*{\s+V2Trap\(\d+\)\s+R=\d+\s+\.(.*?)\s+}\s+}\s*$/i;
	//var trapRegEx=/^\s+((?:\d{1,3}\.){3}\d{1,3})\.\d+\s+>\s+((?:[a-z0-9]+(?:\.|:|-|_)*){1,}):\s+{\s+SNMPv2c\s+{\s+V2Trap\(\d+\)\s+R=\d+\s+\.(.*?)\s+}\s+}\s*$/i;
	var trapOIDRegEx=/\.1\.3\.6\.1\.6\.3\.1\.1\.4\.1\.0=(?:\.)?(1\.3\.6\.(?:\d+\.){1,}\d+)\s*/;
	var isTrap=trapRegEx.exec(line);
	

	if ( isTrap && isTrap.length === 4 ) {

		var sourceIP=isTrap[1];
		var destintionIP=isTrap[2];
		var OIDS=isTrap[3];
		var addedSource=false;
		
		// We now need to look for specific meaningful OIDs (trap OID mostly to enable us to send this on).
		
		var trapOIDRe=trapOIDRegEx.exec(OIDS);

		if ( trapOIDRe && trapOIDRe.length === 2 ) {
			trapData.trapOID=trapOIDRe[1];
		}
		
		// Now iterate throgh the OID key/value pairs and add these. Since we cannot establish what SYNTAX these
		// varbinds are we will set them all as OctetString. 
		// This specifies a minimuim OID length of 3 (.e.g. .1.3.6. is okay .1.3. isn't)
		// We're going to need a look ahead assertion here to allow for quoted (contains spaces)
		// and unquoted (no spaces) 
		// Use stripOIDValue to remove the leading . on OIDs
		// allows the trapd_lam to parse OIDs sent as octerstrings
		// rather than object ids.
	
		var oidKeyValue=/((?:\d+\.){3,}\d+)=("(?:.*?)"|(?:\S+))\s*?/g;

		var oidVal;
		while ( ( oidVal=oidKeyValue.exec(OIDS)) !== null  ) {
			
			var oid=oidVal[1];
			var value=stripOIDValue(oidVal[2]);

			// Add in any OID specific behviour here. 

			// Skip the trap (we've already used it)/
			if ( oid === "1.3.6.1.6.3.1.1.4.1.0" ) {
				continue;
			}
			// Skip the trap number (enterprise specific) 
			if ( oid === "1.3.6.1.2.1.1.3.0" ) {
				continue;
			}
			// If there is an existing snmpTrapAddress - don't add one.
			// MOOG-2745 

		 	if ( oid === "1.3.6.1.6.3.18.1.3.0" ) {
				addedSource = true;
			}
			trapData.varbinds.push({ "oid": oid , type : "OctetString" , "value" : value });
		}

		if ( !addedSource ) {
			// Add an snmpTrapAddress of the original source (taken from the tcp data). 
			// MOOG-2745
            // trapData.varbinds.push({ "oid": "1.3.6.1.4.1.31949.2" , type : "OctetString" , "value" : sourceIP });

			trapData.varbinds.push({ "oid": "1.3.6.1.6.3.18.1.3.0" , type : "IpAddress" , "value" : sourceIP});
		}
		
		// Set the replayer to send the trap. 

		trapData.sendTrap=true;
	}
	return trapData; 
};


var validateOID=function(oid) {
        // We should always start with a 1.3 followed by any number of \.\d+ combinations;
        return /1.3(\.\d+){1,}/.test(oid) ? true : false;
};

// exports.

exports.processLine=processLine;
