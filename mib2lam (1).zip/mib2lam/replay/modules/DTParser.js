
var convertType=function(type) {

	// Convert the DT types to net-snmp types.

	var vbType={
		"COUNTER 32" : "Counter32",
		"GAUGE"	: "Gauge",
		"INTEGER" : "Integer",
		"IPADRESS" : "IpAddress",
		"OBJECT IDENTIFIER" : "OID",
		"OCTET STRING" : "OctetString",
		"TimeTicks" : "TimeTicks"
	};
	return vbType[type] ? vbType[type] : "OctetString";
};


var processLine=function(trapData,line) {
		
	if ( line === "EACHLINE_COMPLETE" ) {

		// Reached the end - try and send what we have.	
		// if it's populated. 

		if ( trapData.trapOID && trapData.new === false ) {
			trapData.sendTrap=true;
			return trapData; 
		}
	}


	// var trapStart=/TRAP_TSV\s+\(\.\s+((?:\d+\.){1,}\d+)\)/;
	// With host to pass as source. 
	var trapStart=/TRAP_TSV\s+\(\.\s+((?:\d+\.){1,}\d+)\)\s+at\s+\d{1,2}\.\s+\D{1,3}\s+\d{4}\s+(?:\d{1,2}:){2}\d{2}\s+(?:\D+)\s+from\s+(.*?)$/;
	var trapVarbind=/state=HAS_VALUE\s+type=(.*?)\s+oid=((?:\d+\.){1,}\d+)\s+value=(.*)$/;

	var isTrapStart=trapStart.exec(line);
	var isVarbind=trapVarbind.exec(line);

	if ( isTrapStart && isTrapStart.length === 3 ) {

		// We are a start of a new trap, or the end of an old trap.
		if ( trapData.new ) {

			// This is the start of a new trap. 
			// populate the trapOID and mark new as false to 
			// allow the next start pattern (TRAP_TSV) to trigger 	
			// sending this trap. 

			trapData.trapOID=isTrapStart[1];
			var trapSource=isTrapStart[2];

			// Push the forwarded varbinds onto the list. 
			// sysContact and snmpTrapAddress
			// Add a lookup for hostname here.

			trapData.varbinds.push({ "oid": "1.3.6.1.2.1.1.4.1" , type : "OctetString" , "value" : "Added by TSV tsvims2a count=1(3000)"});

			// MOOG-2745
			// trapData.varbinds.push({ "oid": "1.3.6.1.6.3.18.1.3.0" , type : "IpAddress" , "value" : "10.0.0.1"});

			trapData.varbinds.push({ "oid": "1.3.6.1.4.1.31949.2" , type : "OctetString" , "value" : trapSource});

			trapData.new=false;
		}
		else {
			// This is the end of an old trap/start of a new one.
			// set reread to true and send the trap
			// allow this line to be reprocessed. 

			trapData.reread=true;
			trapData.sendTrap=true;
		}
	}
	if ( isVarbind && isVarbind.length === 4 ) {
		var vbType=convertType(isVarbind[1]);
		var vbOid=isVarbind[2];
		var vbValue=isVarbind[3];

		// Convert to ints as needed. 

		if ( vbType === "Integer" || vbType === "Counter32" || vbType === "TimeTicks" ) {
			vbValue=parseInt(vbValue);
			if ( isNaN(vbValue) ) {
				vbValue = 0;
			}
		}

		// We can skip upTime and snmpTrapOID (populated by the trap command);

		if ( vbOid !== "1.3.6.1.2.1.1.3.0" && vbOid !== "1.3.6.1.6.3.1.1.4.1.0")  {
			trapData.varbinds.push({ "oid" : vbOid, "type" : vbType , "value" : vbValue});
		}
	}
	return trapData; 
};

// exports.
exports.processLine=processLine;
