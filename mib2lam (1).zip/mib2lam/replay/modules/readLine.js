var stream = require('stream');

var eachLine = new stream.Transform( { objectMode: true } );
 
eachLine._transform = function (chunk, encoding, done) {
	
	// Convert the data to a string
     	var data = chunk.toString()
	
	// Add the last bit of the last chunk to our new data.
     	if (this._lastLineData) {
		data = this._lastLineData + data;
     	}
 
	// Split the data by \n

     	var lines = data.split('\n');

	// Keep the last "bit" to add onto the next chunk 
	// Stops a mid line split causing issues. 

     	this._lastLineData = lines.splice(lines.length-1,1)[0]
 
	// Push the lines.
	for ( var i=0 ; i < lines.length ; i++ ) {
		this.push(lines[i]);
	}
	// Finish the transform 
     	done();
};
 
// Handle the last line of input (to the EOF). 

eachLine._flush = function (done) {

	// Push the last chunk regardless. 

     	if (this._lastLineData) {
		this.push(this._lastLineData)
	}

     	this._lastLineData = null
	this.push("EACHLINE_COMPLETE");
     	done()
};
 
// Export eachLine. 

exports.eachLine = eachLine;

