#!/usr/bin/env node
//
// Utility to replay traps read from a file 
// different formats will require different
// parsers.

//
// Import the correct node packages. 
// ---------------------------------
//  fs - required for reading certificates. 
//  eachLine - used to readl files line by line (uses streams)
//  sendTrap - utility functtions wrapped around net-snmp for sending traps
// 		requires node net-snmp to be installed. 

var fs= require('fs');
var eachLine=require('./modules/readLine.js').eachLine;
var sendTrap=require('./modules/sendTrap.js');

//
// Set some actions when signals are recieved.
//

process.on('SIGINT', function() {
  exit_app("SIGINT recieved, exiting",3);
});
process.on('SIGTERM', function() {
  exit_app("SIGTERM recieved, exiting",3);
});


// Define Global variables/objects
// -------------------------------
// + thisConfig - the object holding the running configuration

var thisConfig;

// Process any command line and config file options. 

var myName=process.argv[1].match(/(?:.*\/)?(.*?)(?:\..*)?$/);
var scriptName;
var fileName;
var numSent=0;

if ( myName && myName.length > 1 ) {
	scriptName=myName[1];
}
else {
	exit_app("Could not determine script, exiting",1);
}

// Use getOpts to parse and set cmd line overrides. 
// all config params can be overridden using the command line. 
// Priotity cmdLine -> config file -> internal defaults. 

var cmdLineOpts=getOpts(process.argv.slice(2));

// Define minimum defaults in case of config file issues. 

var internalDefaults={
	"logLevel" 	:   "info"     ,   	// --logLevel,
	"trapHost"	:   "localhost",	// --traphost
	"trapPort"	:   162,		// --trapport
	"commString"	:   "public"		// --commstring
};

// Look for config and utils to include.

var default_configFile="./" + scriptName + ".conf";		// --config,
var default_utilsFile="./" + scriptName + ".utils";		// --utils,

var configFileLocation=cmdLineOpts.config ? cmdLineOpts.config : default_configFile;
var utilsFileLocation=cmdLineOpts.utils ? cmdLineOpts.utils : default_utilsFile;

// Source in the config and utils modules to allow for config file overrides. 

var configFile = require(configFileLocation).config;
var trapUtils = require(utilsFileLocation);

// Create a new logger - follows standard Moog bot logger format

var logger= new trapUtils.Logger();

logger.info("======== Incident.MOOG : " + scriptName + " =========");

//
// Use command line, config or hard coded defaults. 
//
// All values are strings at this stage - so no type comparison is done only existence. 
// Convert here as needed (e.g wrap in parseInt() ) 

thisConfig={

	// Defaults.

	"logLevel" 	: getParamValue("defaults","logLevel",true,true),
	"trapHost"	: getParamValue("defaults","trapHost",true,true),
	"trapPort"	: getParamValue("defaults","trapPort",true,true),
	"commString"	: getParamValue("defaults","commString",true,true),
	"parserModule"	: getParamValue("defaults","parser",true,true),
	"fileName"	: getParamValue(null,"file",true,true),
	"trap"		: getParamValue(null,"trap",false,true)
};

// Init the parser

var parser=require(thisConfig.parserModule);

logger.info("Configuration checks passed...");
logger.info("----------------------------------------------------");
logger.info("Sending traps to : " + thisConfig.trapHost + ":" + thisConfig.trapPort);
logger.info("Using community string : " + thisConfig.commString);
logger.info("LogLevel : " + thisConfig.logLevel);
logger.info("Reading data from : " + thisConfig.fileName);
logger.info("Using parser : " + thisConfig.parserModule);
if ( thisConfig.trap ) {
	logger.info("Only sending trap with OID " + thisConfig.trap);
}
logger.info("----------------------------------------------------");


// Set the loglevel for the rest of the execution.  

logger.setLogLevel(thisConfig.logLevel);

// -----------------------------------------------------------------------
// Read the file, pass each line to the eachLine module (transform/flush)
// this will split the incoming steam into \n spearated lines for processing by
// the parser. 
// -----------------------------------------------------------------------

// Create the top level SNMP trap session. 
// set any session specific variables 

var snmpSession=new sendTrap.SnmpSession();
snmpSession.setTrapHost(thisConfig.trapHost);
snmpSession.setTrapPort(thisConfig.trapPort);
snmpSession.setCommunity(thisConfig.commString);


// Create the session for use by the trap.
// e.g. var trap=new traps.SnmpTrap(snmpSender);

var snmpSender=snmpSession.createSession();

// Create the stream
// Pipe the source to the stream transform from eachLine. 

var trapStreamData=fs.createReadStream(thisConfig.fileName);

trapStreamData.on("error", function(error) { 

        if ( error.code && error.code === "ENOENT" ) {
                exit_app("File " + thisConfig.fileName + " could not be found",3);
        }
	exit_app("Error with file " + thisConfig.fileName + " - " + error,3);

});


trapStreamData.pipe(eachLine);

eachLine.on("end", function() { 

	logger.warning("Sent " + numSent + " traps");
	logger.warning("========== Exiting " + scriptName + " ==============");

});

// trapPayload structure - populated by the format specific processor. 
// trapOID is expcted to be a trap OID (RFC says it has to be) 
// varbinds is an array of objects with the following properties
// [ { oid : <oid> , type : <type> , value: <value> } , ... ]
// sendTrap should be set to true when it's time to send the trap
// reread: should not be modified - this is used to allow trap patterns to start/end ono
// the same line and be reprocessed

var trapPayload={ trapOID : "", varbinds: [] , sendTrap: false , new: true } ;

// Process the lines as they come through

eachLine.on("readable", function() {
		
	var line;

	// Grab the lines we've been given.
	// iterate though and pass to the parser. 
	// parser will modift the trapPayload as needed. 

	while ( (line=eachLine.read()) ) {
		
		trapPayload=parser.processLine(trapPayload,line);

		if ( trapPayload.sendTrap ) {

			// Send the trap then re-process the line - allows a start/end trap pattern on the same 	
			// line - the start === true  will tell the processor that it's a re-process and 
			// to take this line as the start and not the end. 

			var trap=new sendTrap.SnmpTrap(snmpSender);
			trap.setTrapOID(trapPayload.trapOID);

			for ( var vbIdx = 0 ; vbIdx < trapPayload.varbinds.length ; vbIdx++ ) {
				var vb=trapPayload.varbinds[vbIdx];
				trap.addVarbind(vb.oid, vb.type, vb.value);
			}

			// Send the trap. 
			
			if ( thisConfig.trap ) {
				if ( trap.trapOid === thisConfig.trap ) {
					numSent++;
					trap.sendTrap();
					logger.info("Sending trap (no." + numSent +") OID:" + trap.trapOid + " with " + trap.varbinds.length + " varbinds");
				}
			}
			else {
				numSent++;
				trap.sendTrap();
				logger.info("Sending trap (no." + numSent +") OID:" + trap.trapOid + " with " + trap.varbinds.length + " varbinds");
			}

			if ( trapPayload.reread ) {
				// The processor has detected a start/end pattern on the same line.
				// resend the line (to allow a new trap to be created) - but indicate
				// it's a new trap pattern. 
				trapPayload={ trapOID : "", varbinds: [] , sendTrap: false , new: true } ;
				trapPayload=parser.processLine(trapPayload,line);
			}
			else {
				trapPayload={ trapOID : "", varbinds: [] , sendTrap: false , new: true } ;
			}

		}
		
	}
});



// Helper functions. 

function exit_app(m,c) {

	logger.critical(m);
	logger.critical("========== Exiting " + scriptName + " ==============");
	process.exit(c);
}
		

function getOpts(opts) {

        // The options beginning with a "-" are 
        // flag, the ones that aren't are values.

        // create an object with flags and values. 
        var options={};
        for ( var optIdx = 0; optIdx < opts.length ; optIdx++ ) {

                var flagRe=/^(?:-{1,2})(\w+)$/gi;
                var valueRe=/^[^\-]/;

                var option = opts[optIdx];
                var isFlag=flagRe.exec(option);

                if ( isFlag !== null && isFlag.length > 1 ) {

                        var optionName=isFlag[1].toLowerCase();

			if ( optionName === 'h' || optionName === 'help' ) {

				var helpText="";
				helpText += "\n============= "+ scriptName + " =========\n";
				helpText += "\nUsage: " + scriptName + "\n\n";
				helpText += "[ --config <file> ]\t:\tconfig file name (defaults to ./" + scriptName + ".conf)\n";
				helpText += "[ --utils <file> ]\t:\tutils file name (defaults to ./" + scriptName  + ".utils)\n";
				helpText += "[ --loglevel <level> ]\t:\tlog message level (info|warn|debug|all) (defaults to info)\n";
				helpText += "[ --traphost <host> ]\t:\tThe host you want to send traps to (default to localhost)\n";
				helpText += "[ --trapport <host> ]\t:\tThe port you want to send traps to (defaults to 162)\n";
				helpText += "[ --commstring <host> ]\t:\tThe community stringyou want to send traps with (defaults to public)\n";
				helpText += "[ --file <filename> ]\t:\tthe name of the file to read data from\n";
				helpText += "[ --parser <parser_module> ]\t:\tthe name of the parser to pass the data to (defaults to TCPDumpParser.js)\n";
				helpText += "\nDefaults are hardcoded in the script, override using the config file " + scriptName + ".conf\n";
				helpText += "or use command line overrides (takes precedence over defaults and config file)\n";
				helpText +="\n";
				console.log(helpText);
				process.exit(0);
			}

                        // We've got a flag, check the next arg to 
                        // see if it's a value (i.e. not a flag)

                        var valueIdx=optIdx + 1;
                        if ( valueIdx < opts.length ) {
                                var value = opts[valueIdx];
                                var isValue=valueRe.test(value);
                                if ( isValue === true ) {

                                        // We've got a value, set it, and increment the index.  
                                        // to skip over this value on the next loop.
                                        options[optionName]=value;
                                        optIdx++;
                                }
                                else {
                                        // We got antother flag, so just set this.
                                        options[optionName]=true;
                                }
                        }
                        else {

                                options[optionName]=true;
                        }
                }
                                
        }
        return(options);
}

function getParamValue(varObj,varName,isMandatory,hasValue) {

	// Determine the config parameter option.
	// cmdline trumps the config file which 
	// trumps the internal defaults. 

	// If a param is declared mandatory execution will stop if a value cannot be found.
	// Remember this checks for existense and value
	// so a boolean (set by getOpts of a cmd line arg with no value) is still valid
	// if you are expecting a string - make explicit checks for values if needed. 

	var paramValue;

	if ( typeof internalDefaults[varName] !== 'undefined' ) {
		paramValue=internalDefaults[varName];
	}
	if ( typeof configFile[varObj] !== 'undefined' && typeof configFile[varObj][varName] !== 'undefined' ) {
		paramValue=configFile[varObj][varName];
	}
	// cmdline args are case insensitive. 
	if ( typeof cmdLineOpts[varName.toLowerCase()] !== 'undefined' ) {
		paramValue=cmdLineOpts[varName.toLowerCase()];
	}

	if ( typeof paramValue === "undefined"  ) {
		if ( isMandatory ) {
			exit_app("Could not find a required parameter '" + varName + "' on the commandline, configfile or in defaults",2);
		}
		else {
			return(false);
		}
	}
	if ( hasValue ) {

		if ( !paramValue ) {
			exit_app("Parameter '" + varName + "' expected to have a value but none was found.",2);
		}

		if  (  getObjectType(paramValue) === "boolean" )  {
			exit_app("Parameter '" + varName + "' expected to have a value, found a boolean",2);
		}
	}
			
	return(paramValue);
}

function getObjectType(o) {

        // Get the object prototype, grap the type in a regex, and convert to lowercae.

        return Object.prototype.toString.call(o).match(/^\[object\s(.*)\]/)[1].toLowerCase();

}

